# Portal Oficial do Ministério Livre-Arbítrio - Versão 3.0.0

## Publicação
Envie este ZIP ao Netlify por deploy manual. O arquivo index.html está na raiz.

## Novidades
- Nova Caminhada com Deus
- Eu quero entregar minha vida a Cristo
- Reconciliação
- Biblioteca Bíblica e PDF gratuito
- Testemunhos com opções de privacidade
- Diário do Ministério
- Formulários Netlify para oração, decisão, reconciliação e testemunhos

## Princípio
Feito é melhor que perfeito. Cada página deve servir uma vida.
