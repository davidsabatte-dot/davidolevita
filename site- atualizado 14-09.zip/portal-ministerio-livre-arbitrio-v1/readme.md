# Portal Oficial do Ministério Livre-Arbítrio — Versão 1.0

## Arquivos
- `index.html`: página inicial completa.
- `assets/style.css`: identidade visual e responsividade.
- `assets/script.js`: menu móvel e ano automático.
- `netlify.toml`: configuração básica de publicação e segurança.

## Publicar no Netlify
1. Descompacte o arquivo ZIP.
2. No painel do Netlify, abra o site já criado.
3. Acesse **Deploys**.
4. Arraste a pasta `portal-ministerio-livre-arbitrio-v1` para a área de publicação manual.
5. Aguarde o status **Published**.
6. Abra o endereço do site e teste:
   - menu;
   - botões;
   - formulário de oração;
   - visualização no celular.

## Formulário de oração
O formulário já está preparado para o Netlify Forms com o nome:
`pedido-de-oracao`

Depois do primeiro deploy:
1. Abra **Forms** no Netlify.
2. Confirme que o formulário foi detectado.
3. Faça um envio de teste.
4. Configure notificações por e-mail no painel do Netlify.

## Ajustes obrigatórios antes ou logo após publicar
1. Substituir o link provisório do YouTube pelo endereço exato do canal oficial.
2. Confirmar se o e-mail `contato@davidolevita.com.br` já existe. Caso não exista, substituí-lo.
3. Inserir posteriormente uma foto oficial de David O Levita na seção “Quem Somos”.
4. Adicionar dados reais de apoio/doação somente quando estiverem oficialmente definidos.
5. Configurar o domínio `davidolevita.com.br` no Netlify.

## Foto oficial
A Versão 1.0 usa temporariamente um monograma elegante com a letra “D”. Isso permite publicar imediatamente sem utilizar uma fotografia inadequada, recortada ou de baixa qualidade. A foto pode ser incluída na próxima atualização sem mudar a estrutura da página.

## Observação
Os horários publicados são 06h30, 18h30 e 00h00, com aviso de que podem ocorrer ajustes especiais.
